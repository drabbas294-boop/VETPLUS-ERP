import { prisma } from '@/lib/prisma'
import { NextResponse } from 'next/server'

export async function GET() {
  const bins = await prisma.bin.findMany({ include: { warehouse: true } })
  return NextResponse.json(bins)
}
