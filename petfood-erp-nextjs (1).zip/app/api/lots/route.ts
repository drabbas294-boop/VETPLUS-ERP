import { prisma } from '@/lib/prisma'
import { NextResponse } from 'next/server'
import { z } from 'zod'

const schema = z.object({
  itemId: z.string().cuid(),
  lotNumber: z.string().min(1),
  qty: z.number().nonnegative(),
  uom: z.string(),
  status: z.enum(['QUARANTINE','RELEASED','HOLD']),
  binId: z.string().cuid().optional().or(z.literal(''))
})

export async function POST(req: Request) {
  const data = await req.json()
  const parsed = schema.safeParse({ ...data, qty: Number(data.qty) })
  if (!parsed.success) return NextResponse.json({ error: parsed.error.format() }, { status: 400 })

  const lot = await prisma.inventoryLot.create({
    data: {
      itemId: parsed.data.itemId,
      lotNumber: parsed.data.lotNumber,
      qty: parsed.data.qty,
      uom: parsed.data.uom,
      status: parsed.data.status,
      binId: parsed.data.binId || null
    }
  })
  return NextResponse.json(lot)
}

export async function GET() {
  const lots = await prisma.inventoryLot.findMany({ include: { item: true, bin: { include: { warehouse: true } } }, orderBy: { createdAt: 'desc' } })
  return NextResponse.json(lots)
}
