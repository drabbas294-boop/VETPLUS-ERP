import { prisma } from '@/lib/prisma'

export default async function Dashboard() {
  const [items, lots, suppliers] = await Promise.all([
    prisma.item.count(),
    prisma.inventoryLot.count(),
    prisma.supplier.count()
  ])

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div className="card p-5">
        <div className="text-sm text-gray-500">Items</div>
        <div className="text-3xl font-semibold">{items}</div>
      </div>
      <div className="card p-5">
        <div className="text-sm text-gray-500">Lots</div>
        <div className="text-3xl font-semibold">{lots}</div>
      </div>
      <div className="card p-5">
        <div className="text-sm text-gray-500">Suppliers</div>
        <div className="text-3xl font-semibold">{suppliers}</div>
      </div>

      <div className="card p-5 md:col-span-3">
        <h2 className="text-lg font-semibold mb-3">Quick Links</h2>
        <div className="flex gap-3 flex-wrap">
          <a className="btn" href="/items">Manage Items</a>
          <a className="btn" href="/suppliers">Manage Suppliers</a>
          <a className="btn" href="/inventory/lots">Manage Lots & QA release</a>
        </div>
      </div>
    </div>
  )
}
