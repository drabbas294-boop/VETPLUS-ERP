import { prisma } from '@/lib/prisma'
import LotForm from './ui/LotForm'

export default async function LotsPage() {
  const lots = await prisma.inventoryLot.findMany({ include: { item: true, bin: { include: { warehouse: true } } }, orderBy: { createdAt: 'desc' } })
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div className="md:col-span-2 card p-5">
        <h1 className="text-xl font-semibold mb-3">Inventory Lots</h1>
        <table className="table">
          <thead>
            <tr>
              <th className="th">Item</th>
              <th className="th">Lot</th>
              <th className="th">Qty</th>
              <th className="th">UOM</th>
              <th className="th">Status</th>
              <th className="th">Bin</th>
            </tr>
          </thead>
          <tbody>
            {lots.map(l => (
              <tr key={l.id} className="hover:bg-gray-50">
                <td className="td">{l.item.name}</td>
                <td className="td">{l.lotNumber}</td>
                <td className="td">{l.qty}</td>
                <td className="td">{l.uom}</td>
                <td className="td"><span className="badge">{l.status}</span></td>
                <td className="td">{l.bin ? `${l.bin.warehouse.name}/${l.bin.code}` : '-'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="card p-5">
        <h2 className="text-lg font-semibold mb-3">Create Lot</h2>
        <LotForm />
      </div>
    </div>
  )
}
